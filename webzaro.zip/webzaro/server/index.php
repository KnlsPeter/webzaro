<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SkinCare</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
          theme: {
            extend: {
                colors: {
 'text': {
   50: '#f7f0ed',
   100: '#f0e0db',
   200: '#e0c2b8',
   300: '#d1a394',
   400: '#c28570',
   500: '#b3664d',
   600: '#8f523d',
   700: '#6b3d2e',
   800: '#47291f',
   900: '#24140f',
   950: '#120a08',
 },
 'background': {
   50: '#f7eded',
   100: '#f0dbdb',
   200: '#e0b8b8',
   300: '#d19494',
   400: '#c27070',
   500: '#b34d4d',
   600: '#8f3d3d',
   700: '#6b2e2e',
   800: '#471f1f',
   900: '#240f0f',
   950: '#120808',
 },
 'primary': {
   50: '#f8efec',
   100: '#f1deda',
   200: '#e3bdb5',
   300: '#d69c8f',
   400: '#c87b6a',
   500: '#ba5a45',
   600: '#954837',
   700: '#703629',
   800: '#4a241c',
   900: '#25120e',
   950: '#130907',
 },
 'secondary': {
   50: '#f8f5ed',
   100: '#f1eada',
   200: '#e3d5b5',
   300: '#d5c090',
   400: '#c7ab6b',
   500: '#b99646',
   600: '#947838',
   700: '#6f5a2a',
   800: '#4a3c1c',
   900: '#251e0e',
   950: '#120f07',
 },
 'accent': {
   50: '#f8f8ed',
   100: '#f1f1da',
   200: '#e3e3b5',
   300: '#d5d590',
   400: '#c7c76b',
   500: '#b9b946',
   600: '#949438',
   700: '#6f6f2a',
   800: '#4a4a1c',
   900: '#25250e',
   950: '#121207',
 },
},

            }
          }
        }
      </script>
</head>
<body class="flex flex-col bg-background-50 justify-center">
    <!-- Navbar -->
    <div class="bg-background-200 flex flex-wrap flex-row w-full p-3 gap-10 items-center shadow-[0px_2px_5px_rgba(0,0,0,0.3)] shadow-dark mb-5">
        <a href="#" class="text-3xl font-bold">SkinCare</a>
        <a href="#">Krémek</a>
        <a href="#">Márkák</a>
        <a href="#">Összetevők</a>
        <a href="#">Fórum</a>
        <a href="#">Blog</a>
    </div>

    <!-- Kereső -->
    <div class="flex w-4/12 self-center border-solid rounded-xl border-2 border-text-900 items-center bg-primary-500 text-white p-3 rounded-lg m-3 gap-5 shadow-[0px_2px_50px_rgba(0,0,0,0.3)] shadow-dark">
        <p class="text-lg w-full font-semibold">Összetevő kereső</p>
        <input type="text" class="border-solid rounded-xl border-2 border-text-900 w-full text-white rounded-md p-1 bg-primary-100" placeholder="Keress rá valamire..." name="" id="">
    </div>

    <!-- Tartalom -->

    <!-- Összetevők -->
    <div class="flex self-center flex-col border-solid rounded-xl border-2 border-text-900 m-3 p-3 w-72 bg-accent-50">
        <p class="text-3xl font-bold">Összetevők</p>
        <ul class="px-3">
            <li>Aqua</li>
            <li>Aloe Vera</li>
            <li>Alkohol</li>
            <li>Aminosavak</li>
        </ul>
    </div>

    <!-- Login -->
    <div class="flex gap-5 self-center flex-col border-solid rounded-xl border-2 border-text-900 m-3 p-3 w-72 bg-accent-200">
        <p class="text-3xl self-center font-bold">Belépés</p>
        <input type="text" class="border-solid rounded-xl border-2 border-text-900 w-full text-white rounded-md p-1 bg-accent-50" placeholder="email-cím" name="" id="">
        <input type="text" class="border-solid rounded-xl border-2 border-text-900 w-full text-white rounded-md p-1 bg-accent-50" placeholder="jelszó" name="" id="">
        <div class="self-center border-solid rounded-xl border-2 border-text-900 w-max text-text rounded-md px-2 py-1 bg-accent-100">Belépés</div>
    </div>
</body>
</html>